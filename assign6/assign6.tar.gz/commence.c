#include <stdio.h>
#include <stdlib.h>

int main(){
	char name[500];
	system("clear");
	printf("COMMENCING CONFERENCE: RESPOND\n");
	return 0;
}